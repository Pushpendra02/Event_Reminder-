package com.example.eventreminder.database;

public class CommonDatabase {
    public static EventDatabase db;
}
